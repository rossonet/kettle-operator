--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4 (Debian 14.4-1.pgdg110+1)
-- Dumped by pg_dump version 14.4 (Debian 14.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: r_cluster; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_cluster (
    id_cluster bigint NOT NULL,
    "NAME" character varying(255),
    base_port character varying(255),
    sockets_buffer_size character varying(255),
    sockets_flush_interval character varying(255),
    sockets_compressed boolean,
    dynamic_cluster boolean
);


ALTER TABLE public.r_cluster OWNER TO rossonet;

--
-- Name: r_cluster_id_cluster_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_cluster_id_cluster_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_cluster_id_cluster_seq OWNER TO rossonet;

--
-- Name: r_cluster_id_cluster_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_cluster_id_cluster_seq OWNED BY public.r_cluster.id_cluster;


--
-- Name: r_cluster_slave; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_cluster_slave (
    id_cluster_slave bigint NOT NULL,
    id_cluster integer,
    id_slave integer
);


ALTER TABLE public.r_cluster_slave OWNER TO rossonet;

--
-- Name: r_cluster_slave_id_cluster_slave_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_cluster_slave_id_cluster_slave_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_cluster_slave_id_cluster_slave_seq OWNER TO rossonet;

--
-- Name: r_cluster_slave_id_cluster_slave_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_cluster_slave_id_cluster_slave_seq OWNED BY public.r_cluster_slave.id_cluster_slave;


--
-- Name: r_condition; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_condition (
    id_condition bigint NOT NULL,
    id_condition_parent integer,
    negated boolean,
    "OPERATOR" character varying(255),
    left_name character varying(255),
    condition_function character varying(255),
    right_name character varying(255),
    id_value_right integer
);


ALTER TABLE public.r_condition OWNER TO rossonet;

--
-- Name: r_condition_id_condition_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_condition_id_condition_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_condition_id_condition_seq OWNER TO rossonet;

--
-- Name: r_condition_id_condition_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_condition_id_condition_seq OWNED BY public.r_condition.id_condition;


--
-- Name: r_database; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_database (
    id_database bigint NOT NULL,
    "NAME" character varying(255),
    id_database_type integer,
    id_database_contype integer,
    host_name character varying(255),
    database_name character varying(2000000),
    port integer,
    username character varying(255),
    "PASSWORD" character varying(255),
    servername character varying(255),
    data_tbs character varying(255),
    index_tbs character varying(255)
);


ALTER TABLE public.r_database OWNER TO rossonet;

--
-- Name: r_database_attribute; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_database_attribute (
    id_database_attribute bigint NOT NULL,
    id_database integer,
    code character varying(255),
    value_str character varying(2000000)
);


ALTER TABLE public.r_database_attribute OWNER TO rossonet;

--
-- Name: r_database_attribute_id_database_attribute_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_database_attribute_id_database_attribute_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_database_attribute_id_database_attribute_seq OWNER TO rossonet;

--
-- Name: r_database_attribute_id_database_attribute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_database_attribute_id_database_attribute_seq OWNED BY public.r_database_attribute.id_database_attribute;


--
-- Name: r_database_contype; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_database_contype (
    id_database_contype bigint NOT NULL,
    code character varying(255),
    description character varying(255)
);


ALTER TABLE public.r_database_contype OWNER TO rossonet;

--
-- Name: r_database_contype_id_database_contype_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_database_contype_id_database_contype_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_database_contype_id_database_contype_seq OWNER TO rossonet;

--
-- Name: r_database_contype_id_database_contype_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_database_contype_id_database_contype_seq OWNED BY public.r_database_contype.id_database_contype;


--
-- Name: r_database_id_database_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_database_id_database_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_database_id_database_seq OWNER TO rossonet;

--
-- Name: r_database_id_database_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_database_id_database_seq OWNED BY public.r_database.id_database;


--
-- Name: r_database_type; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_database_type (
    id_database_type bigint NOT NULL,
    code character varying(255),
    description character varying(255)
);


ALTER TABLE public.r_database_type OWNER TO rossonet;

--
-- Name: r_database_type_id_database_type_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_database_type_id_database_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_database_type_id_database_type_seq OWNER TO rossonet;

--
-- Name: r_database_type_id_database_type_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_database_type_id_database_type_seq OWNED BY public.r_database_type.id_database_type;


--
-- Name: r_dependency; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_dependency (
    id_dependency bigint NOT NULL,
    id_transformation integer,
    id_database integer,
    "TABLE_NAME" character varying(255),
    field_name character varying(255)
);


ALTER TABLE public.r_dependency OWNER TO rossonet;

--
-- Name: r_dependency_id_dependency_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_dependency_id_dependency_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_dependency_id_dependency_seq OWNER TO rossonet;

--
-- Name: r_dependency_id_dependency_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_dependency_id_dependency_seq OWNED BY public.r_dependency.id_dependency;


--
-- Name: r_directory; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_directory (
    id_directory bigint NOT NULL,
    id_directory_parent integer,
    directory_name character varying(255)
);


ALTER TABLE public.r_directory OWNER TO rossonet;

--
-- Name: r_directory_id_directory_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_directory_id_directory_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_directory_id_directory_seq OWNER TO rossonet;

--
-- Name: r_directory_id_directory_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_directory_id_directory_seq OWNED BY public.r_directory.id_directory;


--
-- Name: r_element; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_element (
    id_element bigint NOT NULL,
    id_element_type integer,
    "NAME" text
);


ALTER TABLE public.r_element OWNER TO rossonet;

--
-- Name: r_element_attribute; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_element_attribute (
    id_element_attribute bigint NOT NULL,
    id_element integer,
    id_element_attribute_parent integer,
    attr_key character varying(255),
    attr_value character varying(2000000)
);


ALTER TABLE public.r_element_attribute OWNER TO rossonet;

--
-- Name: r_element_attribute_id_element_attribute_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_element_attribute_id_element_attribute_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_element_attribute_id_element_attribute_seq OWNER TO rossonet;

--
-- Name: r_element_attribute_id_element_attribute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_element_attribute_id_element_attribute_seq OWNED BY public.r_element_attribute.id_element_attribute;


--
-- Name: r_element_id_element_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_element_id_element_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_element_id_element_seq OWNER TO rossonet;

--
-- Name: r_element_id_element_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_element_id_element_seq OWNED BY public.r_element.id_element;


--
-- Name: r_element_type; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_element_type (
    id_element_type bigint NOT NULL,
    id_namespace integer,
    "NAME" text,
    description character varying(2000000)
);


ALTER TABLE public.r_element_type OWNER TO rossonet;

--
-- Name: r_element_type_id_element_type_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_element_type_id_element_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_element_type_id_element_type_seq OWNER TO rossonet;

--
-- Name: r_element_type_id_element_type_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_element_type_id_element_type_seq OWNED BY public.r_element_type.id_element_type;


--
-- Name: r_job; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_job (
    id_job bigint NOT NULL,
    id_directory integer,
    "NAME" character varying(255),
    description character varying(2000000),
    extended_description character varying(2000000),
    job_version character varying(255),
    job_status integer,
    id_database_log integer,
    table_name_log character varying(255),
    created_user character varying(255),
    created_date timestamp without time zone,
    modified_user character varying(255),
    modified_date timestamp without time zone,
    use_batch_id boolean,
    pass_batch_id boolean,
    use_logfield boolean,
    shared_file character varying(255)
);


ALTER TABLE public.r_job OWNER TO rossonet;

--
-- Name: r_job_attribute; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_job_attribute (
    id_job_attribute bigint NOT NULL,
    id_job integer,
    nr integer,
    code character varying(255),
    value_num bigint,
    value_str character varying(2000000)
);


ALTER TABLE public.r_job_attribute OWNER TO rossonet;

--
-- Name: r_job_attribute_id_job_attribute_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_job_attribute_id_job_attribute_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_job_attribute_id_job_attribute_seq OWNER TO rossonet;

--
-- Name: r_job_attribute_id_job_attribute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_job_attribute_id_job_attribute_seq OWNED BY public.r_job_attribute.id_job_attribute;


--
-- Name: r_job_hop; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_job_hop (
    id_job_hop bigint NOT NULL,
    id_job integer,
    id_jobentry_copy_from integer,
    id_jobentry_copy_to integer,
    enabled boolean,
    evaluation boolean,
    unconditional boolean
);


ALTER TABLE public.r_job_hop OWNER TO rossonet;

--
-- Name: r_job_hop_id_job_hop_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_job_hop_id_job_hop_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_job_hop_id_job_hop_seq OWNER TO rossonet;

--
-- Name: r_job_hop_id_job_hop_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_job_hop_id_job_hop_seq OWNED BY public.r_job_hop.id_job_hop;


--
-- Name: r_job_id_job_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_job_id_job_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_job_id_job_seq OWNER TO rossonet;

--
-- Name: r_job_id_job_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_job_id_job_seq OWNED BY public.r_job.id_job;


--
-- Name: r_job_lock; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_job_lock (
    id_job_lock bigint NOT NULL,
    id_job integer,
    id_user integer,
    lock_message character varying(2000000),
    lock_date timestamp without time zone
);


ALTER TABLE public.r_job_lock OWNER TO rossonet;

--
-- Name: r_job_lock_id_job_lock_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_job_lock_id_job_lock_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_job_lock_id_job_lock_seq OWNER TO rossonet;

--
-- Name: r_job_lock_id_job_lock_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_job_lock_id_job_lock_seq OWNED BY public.r_job_lock.id_job_lock;


--
-- Name: r_job_note; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_job_note (
    id_job integer,
    id_note integer
);


ALTER TABLE public.r_job_note OWNER TO rossonet;

--
-- Name: r_jobentry; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_jobentry (
    id_jobentry bigint NOT NULL,
    id_job integer,
    id_jobentry_type integer,
    "NAME" character varying(255),
    description character varying(2000000)
);


ALTER TABLE public.r_jobentry OWNER TO rossonet;

--
-- Name: r_jobentry_attribute; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_jobentry_attribute (
    id_jobentry_attribute bigint NOT NULL,
    id_job integer,
    id_jobentry integer,
    nr integer,
    code character varying(255),
    value_num numeric(15,2),
    value_str character varying(2000000)
);


ALTER TABLE public.r_jobentry_attribute OWNER TO rossonet;

--
-- Name: r_jobentry_attribute_id_jobentry_attribute_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_jobentry_attribute_id_jobentry_attribute_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_jobentry_attribute_id_jobentry_attribute_seq OWNER TO rossonet;

--
-- Name: r_jobentry_attribute_id_jobentry_attribute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_jobentry_attribute_id_jobentry_attribute_seq OWNED BY public.r_jobentry_attribute.id_jobentry_attribute;


--
-- Name: r_jobentry_copy; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_jobentry_copy (
    id_jobentry_copy bigint NOT NULL,
    id_jobentry integer,
    id_job integer,
    id_jobentry_type integer,
    nr smallint,
    gui_location_x integer,
    gui_location_y integer,
    gui_draw boolean,
    parallel boolean
);


ALTER TABLE public.r_jobentry_copy OWNER TO rossonet;

--
-- Name: r_jobentry_copy_id_jobentry_copy_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_jobentry_copy_id_jobentry_copy_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_jobentry_copy_id_jobentry_copy_seq OWNER TO rossonet;

--
-- Name: r_jobentry_copy_id_jobentry_copy_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_jobentry_copy_id_jobentry_copy_seq OWNED BY public.r_jobentry_copy.id_jobentry_copy;


--
-- Name: r_jobentry_database; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_jobentry_database (
    id_job integer,
    id_jobentry integer,
    id_database integer
);


ALTER TABLE public.r_jobentry_database OWNER TO rossonet;

--
-- Name: r_jobentry_id_jobentry_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_jobentry_id_jobentry_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_jobentry_id_jobentry_seq OWNER TO rossonet;

--
-- Name: r_jobentry_id_jobentry_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_jobentry_id_jobentry_seq OWNED BY public.r_jobentry.id_jobentry;


--
-- Name: r_jobentry_type; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_jobentry_type (
    id_jobentry_type bigint NOT NULL,
    code character varying(255),
    description character varying(255)
);


ALTER TABLE public.r_jobentry_type OWNER TO rossonet;

--
-- Name: r_jobentry_type_id_jobentry_type_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_jobentry_type_id_jobentry_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_jobentry_type_id_jobentry_type_seq OWNER TO rossonet;

--
-- Name: r_jobentry_type_id_jobentry_type_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_jobentry_type_id_jobentry_type_seq OWNED BY public.r_jobentry_type.id_jobentry_type;


--
-- Name: r_log; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_log (
    id_log bigint NOT NULL,
    "NAME" character varying(255),
    id_loglevel integer,
    logtype character varying(255),
    filename character varying(255),
    fileextention character varying(255),
    add_date boolean,
    add_time boolean,
    id_database_log integer,
    table_name_log character varying(255)
);


ALTER TABLE public.r_log OWNER TO rossonet;

--
-- Name: r_log_id_log_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_log_id_log_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_log_id_log_seq OWNER TO rossonet;

--
-- Name: r_log_id_log_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_log_id_log_seq OWNED BY public.r_log.id_log;


--
-- Name: r_loglevel; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_loglevel (
    id_loglevel bigint NOT NULL,
    code character varying(255),
    description character varying(255)
);


ALTER TABLE public.r_loglevel OWNER TO rossonet;

--
-- Name: r_loglevel_id_loglevel_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_loglevel_id_loglevel_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_loglevel_id_loglevel_seq OWNER TO rossonet;

--
-- Name: r_loglevel_id_loglevel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_loglevel_id_loglevel_seq OWNED BY public.r_loglevel.id_loglevel;


--
-- Name: r_namespace; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_namespace (
    id_namespace bigint NOT NULL,
    "NAME" text
);


ALTER TABLE public.r_namespace OWNER TO rossonet;

--
-- Name: r_namespace_id_namespace_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_namespace_id_namespace_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_namespace_id_namespace_seq OWNER TO rossonet;

--
-- Name: r_namespace_id_namespace_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_namespace_id_namespace_seq OWNED BY public.r_namespace.id_namespace;


--
-- Name: r_note; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_note (
    id_note bigint NOT NULL,
    value_str character varying(2000000),
    gui_location_x integer,
    gui_location_y integer,
    gui_location_width integer,
    gui_location_height integer,
    font_name character varying(2000000),
    font_size integer,
    font_bold boolean,
    font_italic boolean,
    font_color_red integer,
    font_color_green integer,
    font_color_blue integer,
    font_back_ground_color_red integer,
    font_back_ground_color_green integer,
    font_back_ground_color_blue integer,
    font_border_color_red integer,
    font_border_color_green integer,
    font_border_color_blue integer,
    draw_shadow boolean
);


ALTER TABLE public.r_note OWNER TO rossonet;

--
-- Name: r_note_id_note_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_note_id_note_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_note_id_note_seq OWNER TO rossonet;

--
-- Name: r_note_id_note_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_note_id_note_seq OWNED BY public.r_note.id_note;


--
-- Name: r_partition; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_partition (
    id_partition bigint NOT NULL,
    id_partition_schema integer,
    partition_id character varying(255)
);


ALTER TABLE public.r_partition OWNER TO rossonet;

--
-- Name: r_partition_id_partition_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_partition_id_partition_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_partition_id_partition_seq OWNER TO rossonet;

--
-- Name: r_partition_id_partition_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_partition_id_partition_seq OWNED BY public.r_partition.id_partition;


--
-- Name: r_partition_schema; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_partition_schema (
    id_partition_schema bigint NOT NULL,
    "NAME" character varying(255),
    dynamic_definition boolean,
    partitions_per_slave character varying(255)
);


ALTER TABLE public.r_partition_schema OWNER TO rossonet;

--
-- Name: r_partition_schema_id_partition_schema_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_partition_schema_id_partition_schema_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_partition_schema_id_partition_schema_seq OWNER TO rossonet;

--
-- Name: r_partition_schema_id_partition_schema_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_partition_schema_id_partition_schema_seq OWNED BY public.r_partition_schema.id_partition_schema;


--
-- Name: r_repository_log; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_repository_log (
    id_repository_log bigint NOT NULL,
    rep_version character varying(255),
    log_date timestamp without time zone,
    log_user character varying(255),
    operation_desc character varying(2000000)
);


ALTER TABLE public.r_repository_log OWNER TO rossonet;

--
-- Name: r_repository_log_id_repository_log_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_repository_log_id_repository_log_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_repository_log_id_repository_log_seq OWNER TO rossonet;

--
-- Name: r_repository_log_id_repository_log_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_repository_log_id_repository_log_seq OWNED BY public.r_repository_log.id_repository_log;


--
-- Name: r_slave; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_slave (
    id_slave bigint NOT NULL,
    "NAME" character varying(255),
    host_name character varying(255),
    port character varying(255),
    web_app_name character varying(255),
    username character varying(255),
    "PASSWORD" character varying(255),
    proxy_host_name character varying(255),
    proxy_port character varying(255),
    non_proxy_hosts character varying(255),
    master boolean
);


ALTER TABLE public.r_slave OWNER TO rossonet;

--
-- Name: r_slave_id_slave_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_slave_id_slave_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_slave_id_slave_seq OWNER TO rossonet;

--
-- Name: r_slave_id_slave_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_slave_id_slave_seq OWNED BY public.r_slave.id_slave;


--
-- Name: r_step; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_step (
    id_step bigint NOT NULL,
    id_transformation integer,
    "NAME" character varying(255),
    description character varying(2000000),
    id_step_type integer,
    distribute boolean,
    copies smallint,
    gui_location_x integer,
    gui_location_y integer,
    gui_draw boolean,
    copies_string character varying(255)
);


ALTER TABLE public.r_step OWNER TO rossonet;

--
-- Name: r_step_attribute; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_step_attribute (
    id_step_attribute bigint NOT NULL,
    id_transformation integer,
    id_step integer,
    nr integer,
    code character varying(255),
    value_num bigint,
    value_str character varying(2000000)
);


ALTER TABLE public.r_step_attribute OWNER TO rossonet;

--
-- Name: r_step_attribute_id_step_attribute_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_step_attribute_id_step_attribute_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_step_attribute_id_step_attribute_seq OWNER TO rossonet;

--
-- Name: r_step_attribute_id_step_attribute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_step_attribute_id_step_attribute_seq OWNED BY public.r_step_attribute.id_step_attribute;


--
-- Name: r_step_database; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_step_database (
    id_transformation integer,
    id_step integer,
    id_database integer
);


ALTER TABLE public.r_step_database OWNER TO rossonet;

--
-- Name: r_step_id_step_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_step_id_step_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_step_id_step_seq OWNER TO rossonet;

--
-- Name: r_step_id_step_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_step_id_step_seq OWNED BY public.r_step.id_step;


--
-- Name: r_step_type; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_step_type (
    id_step_type bigint NOT NULL,
    code character varying(255),
    description character varying(255),
    helptext character varying(255)
);


ALTER TABLE public.r_step_type OWNER TO rossonet;

--
-- Name: r_step_type_id_step_type_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_step_type_id_step_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_step_type_id_step_type_seq OWNER TO rossonet;

--
-- Name: r_step_type_id_step_type_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_step_type_id_step_type_seq OWNED BY public.r_step_type.id_step_type;


--
-- Name: r_trans_attribute; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_attribute (
    id_trans_attribute bigint NOT NULL,
    id_transformation integer,
    nr integer,
    code character varying(255),
    value_num bigint,
    value_str character varying(2000000)
);


ALTER TABLE public.r_trans_attribute OWNER TO rossonet;

--
-- Name: r_trans_attribute_id_trans_attribute_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_trans_attribute_id_trans_attribute_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_trans_attribute_id_trans_attribute_seq OWNER TO rossonet;

--
-- Name: r_trans_attribute_id_trans_attribute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_trans_attribute_id_trans_attribute_seq OWNED BY public.r_trans_attribute.id_trans_attribute;


--
-- Name: r_trans_cluster; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_cluster (
    id_trans_cluster bigint NOT NULL,
    id_transformation integer,
    id_cluster integer
);


ALTER TABLE public.r_trans_cluster OWNER TO rossonet;

--
-- Name: r_trans_cluster_id_trans_cluster_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_trans_cluster_id_trans_cluster_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_trans_cluster_id_trans_cluster_seq OWNER TO rossonet;

--
-- Name: r_trans_cluster_id_trans_cluster_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_trans_cluster_id_trans_cluster_seq OWNED BY public.r_trans_cluster.id_trans_cluster;


--
-- Name: r_trans_hop; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_hop (
    id_trans_hop bigint NOT NULL,
    id_transformation integer,
    id_step_from integer,
    id_step_to integer,
    enabled boolean
);


ALTER TABLE public.r_trans_hop OWNER TO rossonet;

--
-- Name: r_trans_hop_id_trans_hop_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_trans_hop_id_trans_hop_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_trans_hop_id_trans_hop_seq OWNER TO rossonet;

--
-- Name: r_trans_hop_id_trans_hop_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_trans_hop_id_trans_hop_seq OWNED BY public.r_trans_hop.id_trans_hop;


--
-- Name: r_trans_lock; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_lock (
    id_trans_lock bigint NOT NULL,
    id_transformation integer,
    id_user integer,
    lock_message character varying(2000000),
    lock_date timestamp without time zone
);


ALTER TABLE public.r_trans_lock OWNER TO rossonet;

--
-- Name: r_trans_lock_id_trans_lock_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_trans_lock_id_trans_lock_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_trans_lock_id_trans_lock_seq OWNER TO rossonet;

--
-- Name: r_trans_lock_id_trans_lock_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_trans_lock_id_trans_lock_seq OWNED BY public.r_trans_lock.id_trans_lock;


--
-- Name: r_trans_note; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_note (
    id_transformation integer,
    id_note integer
);


ALTER TABLE public.r_trans_note OWNER TO rossonet;

--
-- Name: r_trans_partition_schema; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_partition_schema (
    id_trans_partition_schema bigint NOT NULL,
    id_transformation integer,
    id_partition_schema integer
);


ALTER TABLE public.r_trans_partition_schema OWNER TO rossonet;

--
-- Name: r_trans_partition_schema_id_trans_partition_schema_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_trans_partition_schema_id_trans_partition_schema_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_trans_partition_schema_id_trans_partition_schema_seq OWNER TO rossonet;

--
-- Name: r_trans_partition_schema_id_trans_partition_schema_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_trans_partition_schema_id_trans_partition_schema_seq OWNED BY public.r_trans_partition_schema.id_trans_partition_schema;


--
-- Name: r_trans_slave; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_slave (
    id_trans_slave bigint NOT NULL,
    id_transformation integer,
    id_slave integer
);


ALTER TABLE public.r_trans_slave OWNER TO rossonet;

--
-- Name: r_trans_slave_id_trans_slave_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_trans_slave_id_trans_slave_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_trans_slave_id_trans_slave_seq OWNER TO rossonet;

--
-- Name: r_trans_slave_id_trans_slave_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_trans_slave_id_trans_slave_seq OWNED BY public.r_trans_slave.id_trans_slave;


--
-- Name: r_trans_step_condition; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_trans_step_condition (
    id_transformation integer,
    id_step integer,
    id_condition integer
);


ALTER TABLE public.r_trans_step_condition OWNER TO rossonet;

--
-- Name: r_transformation; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_transformation (
    id_transformation bigint NOT NULL,
    id_directory integer,
    "NAME" character varying(255),
    description character varying(2000000),
    extended_description character varying(2000000),
    trans_version character varying(255),
    trans_status integer,
    id_step_read integer,
    id_step_write integer,
    id_step_input integer,
    id_step_output integer,
    id_step_update integer,
    id_database_log integer,
    table_name_log character varying(255),
    use_batchid boolean,
    use_logfield boolean,
    id_database_maxdate integer,
    table_name_maxdate character varying(255),
    field_name_maxdate character varying(255),
    offset_maxdate numeric(14,2),
    diff_maxdate numeric(14,2),
    created_user character varying(255),
    created_date timestamp without time zone,
    modified_user character varying(255),
    modified_date timestamp without time zone,
    size_rowset integer
);


ALTER TABLE public.r_transformation OWNER TO rossonet;

--
-- Name: r_transformation_id_transformation_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_transformation_id_transformation_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_transformation_id_transformation_seq OWNER TO rossonet;

--
-- Name: r_transformation_id_transformation_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_transformation_id_transformation_seq OWNED BY public.r_transformation.id_transformation;


--
-- Name: r_user; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_user (
    id_user bigint NOT NULL,
    "LOGIN" character varying(255),
    "PASSWORD" character varying(255),
    "NAME" character varying(255),
    description character varying(255),
    enabled boolean
);


ALTER TABLE public.r_user OWNER TO rossonet;

--
-- Name: r_user_id_user_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_user_id_user_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_user_id_user_seq OWNER TO rossonet;

--
-- Name: r_user_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_user_id_user_seq OWNED BY public.r_user.id_user;


--
-- Name: r_value; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_value (
    id_value bigint NOT NULL,
    "NAME" character varying(255),
    value_type character varying(255),
    value_str character varying(255),
    is_null boolean
);


ALTER TABLE public.r_value OWNER TO rossonet;

--
-- Name: r_value_id_value_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_value_id_value_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_value_id_value_seq OWNER TO rossonet;

--
-- Name: r_value_id_value_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_value_id_value_seq OWNED BY public.r_value.id_value;


--
-- Name: r_version; Type: TABLE; Schema: public; Owner: rossonet
--

CREATE TABLE public.r_version (
    id_version bigint NOT NULL,
    major_version smallint,
    minor_version smallint,
    upgrade_date timestamp without time zone,
    is_upgrade boolean
);


ALTER TABLE public.r_version OWNER TO rossonet;

--
-- Name: r_version_id_version_seq; Type: SEQUENCE; Schema: public; Owner: rossonet
--

CREATE SEQUENCE public.r_version_id_version_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_version_id_version_seq OWNER TO rossonet;

--
-- Name: r_version_id_version_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rossonet
--

ALTER SEQUENCE public.r_version_id_version_seq OWNED BY public.r_version.id_version;


--
-- Name: r_cluster id_cluster; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_cluster ALTER COLUMN id_cluster SET DEFAULT nextval('public.r_cluster_id_cluster_seq'::regclass);


--
-- Name: r_cluster_slave id_cluster_slave; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_cluster_slave ALTER COLUMN id_cluster_slave SET DEFAULT nextval('public.r_cluster_slave_id_cluster_slave_seq'::regclass);


--
-- Name: r_condition id_condition; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_condition ALTER COLUMN id_condition SET DEFAULT nextval('public.r_condition_id_condition_seq'::regclass);


--
-- Name: r_database id_database; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_database ALTER COLUMN id_database SET DEFAULT nextval('public.r_database_id_database_seq'::regclass);


--
-- Name: r_database_attribute id_database_attribute; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_database_attribute ALTER COLUMN id_database_attribute SET DEFAULT nextval('public.r_database_attribute_id_database_attribute_seq'::regclass);


--
-- Name: r_database_contype id_database_contype; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_database_contype ALTER COLUMN id_database_contype SET DEFAULT nextval('public.r_database_contype_id_database_contype_seq'::regclass);


--
-- Name: r_database_type id_database_type; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_database_type ALTER COLUMN id_database_type SET DEFAULT nextval('public.r_database_type_id_database_type_seq'::regclass);


--
-- Name: r_dependency id_dependency; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_dependency ALTER COLUMN id_dependency SET DEFAULT nextval('public.r_dependency_id_dependency_seq'::regclass);


--
-- Name: r_directory id_directory; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_directory ALTER COLUMN id_directory SET DEFAULT nextval('public.r_directory_id_directory_seq'::regclass);


--
-- Name: r_element id_element; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_element ALTER COLUMN id_element SET DEFAULT nextval('public.r_element_id_element_seq'::regclass);


--
-- Name: r_element_attribute id_element_attribute; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_element_attribute ALTER COLUMN id_element_attribute SET DEFAULT nextval('public.r_element_attribute_id_element_attribute_seq'::regclass);


--
-- Name: r_element_type id_element_type; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_element_type ALTER COLUMN id_element_type SET DEFAULT nextval('public.r_element_type_id_element_type_seq'::regclass);


--
-- Name: r_job id_job; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_job ALTER COLUMN id_job SET DEFAULT nextval('public.r_job_id_job_seq'::regclass);


--
-- Name: r_job_attribute id_job_attribute; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_job_attribute ALTER COLUMN id_job_attribute SET DEFAULT nextval('public.r_job_attribute_id_job_attribute_seq'::regclass);


--
-- Name: r_job_hop id_job_hop; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_job_hop ALTER COLUMN id_job_hop SET DEFAULT nextval('public.r_job_hop_id_job_hop_seq'::regclass);


--
-- Name: r_job_lock id_job_lock; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_job_lock ALTER COLUMN id_job_lock SET DEFAULT nextval('public.r_job_lock_id_job_lock_seq'::regclass);


--
-- Name: r_jobentry id_jobentry; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_jobentry ALTER COLUMN id_jobentry SET DEFAULT nextval('public.r_jobentry_id_jobentry_seq'::regclass);


--
-- Name: r_jobentry_attribute id_jobentry_attribute; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_jobentry_attribute ALTER COLUMN id_jobentry_attribute SET DEFAULT nextval('public.r_jobentry_attribute_id_jobentry_attribute_seq'::regclass);


--
-- Name: r_jobentry_copy id_jobentry_copy; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_jobentry_copy ALTER COLUMN id_jobentry_copy SET DEFAULT nextval('public.r_jobentry_copy_id_jobentry_copy_seq'::regclass);


--
-- Name: r_jobentry_type id_jobentry_type; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_jobentry_type ALTER COLUMN id_jobentry_type SET DEFAULT nextval('public.r_jobentry_type_id_jobentry_type_seq'::regclass);


--
-- Name: r_log id_log; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_log ALTER COLUMN id_log SET DEFAULT nextval('public.r_log_id_log_seq'::regclass);


--
-- Name: r_loglevel id_loglevel; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_loglevel ALTER COLUMN id_loglevel SET DEFAULT nextval('public.r_loglevel_id_loglevel_seq'::regclass);


--
-- Name: r_namespace id_namespace; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_namespace ALTER COLUMN id_namespace SET DEFAULT nextval('public.r_namespace_id_namespace_seq'::regclass);


--
-- Name: r_note id_note; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_note ALTER COLUMN id_note SET DEFAULT nextval('public.r_note_id_note_seq'::regclass);


--
-- Name: r_partition id_partition; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_partition ALTER COLUMN id_partition SET DEFAULT nextval('public.r_partition_id_partition_seq'::regclass);


--
-- Name: r_partition_schema id_partition_schema; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_partition_schema ALTER COLUMN id_partition_schema SET DEFAULT nextval('public.r_partition_schema_id_partition_schema_seq'::regclass);


--
-- Name: r_repository_log id_repository_log; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_repository_log ALTER COLUMN id_repository_log SET DEFAULT nextval('public.r_repository_log_id_repository_log_seq'::regclass);


--
-- Name: r_slave id_slave; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_slave ALTER COLUMN id_slave SET DEFAULT nextval('public.r_slave_id_slave_seq'::regclass);


--
-- Name: r_step id_step; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_step ALTER COLUMN id_step SET DEFAULT nextval('public.r_step_id_step_seq'::regclass);


--
-- Name: r_step_attribute id_step_attribute; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_step_attribute ALTER COLUMN id_step_attribute SET DEFAULT nextval('public.r_step_attribute_id_step_attribute_seq'::regclass);


--
-- Name: r_step_type id_step_type; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_step_type ALTER COLUMN id_step_type SET DEFAULT nextval('public.r_step_type_id_step_type_seq'::regclass);


--
-- Name: r_trans_attribute id_trans_attribute; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_trans_attribute ALTER COLUMN id_trans_attribute SET DEFAULT nextval('public.r_trans_attribute_id_trans_attribute_seq'::regclass);


--
-- Name: r_trans_cluster id_trans_cluster; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_trans_cluster ALTER COLUMN id_trans_cluster SET DEFAULT nextval('public.r_trans_cluster_id_trans_cluster_seq'::regclass);


--
-- Name: r_trans_hop id_trans_hop; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_trans_hop ALTER COLUMN id_trans_hop SET DEFAULT nextval('public.r_trans_hop_id_trans_hop_seq'::regclass);


--
-- Name: r_trans_lock id_trans_lock; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_trans_lock ALTER COLUMN id_trans_lock SET DEFAULT nextval('public.r_trans_lock_id_trans_lock_seq'::regclass);


--
-- Name: r_trans_partition_schema id_trans_partition_schema; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_trans_partition_schema ALTER COLUMN id_trans_partition_schema SET DEFAULT nextval('public.r_trans_partition_schema_id_trans_partition_schema_seq'::regclass);


--
-- Name: r_trans_slave id_trans_slave; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_trans_slave ALTER COLUMN id_trans_slave SET DEFAULT nextval('public.r_trans_slave_id_trans_slave_seq'::regclass);


--
-- Name: r_transformation id_transformation; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_transformation ALTER COLUMN id_transformation SET DEFAULT nextval('public.r_transformation_id_transformation_seq'::regclass);


--
-- Name: r_user id_user; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_user ALTER COLUMN id_user SET DEFAULT nextval('public.r_user_id_user_seq'::regclass);


--
-- Name: r_value id_value; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_value ALTER COLUMN id_value SET DEFAULT nextval('public.r_value_id_value_seq'::regclass);


--
-- Name: r_version id_version; Type: DEFAULT; Schema: public; Owner: rossonet
--

ALTER TABLE ONLY public.r_version ALTER COLUMN id_version SET DEFAULT nextval('public.r_version_id_version_seq'::regclass);


--
-- Data for Name: r_cluster; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_cluster (id_cluster, "NAME", base_port, sockets_buffer_size, sockets_flush_interval, sockets_compressed, dynamic_cluster) FROM stdin;
\.


--
-- Data for Name: r_cluster_slave; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_cluster_slave (id_cluster_slave, id_cluster, id_slave) FROM stdin;
\.


--
-- Data for Name: r_condition; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_condition (id_condition, id_condition_parent, negated, "OPERATOR", left_name, condition_function, right_name, id_value_right) FROM stdin;
\.


--
-- Data for Name: r_database; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_database (id_database, "NAME", id_database_type, id_database_contype, host_name, database_name, port, username, "PASSWORD", servername, data_tbs, index_tbs) FROM stdin;
\.


--
-- Data for Name: r_database_attribute; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_database_attribute (id_database_attribute, id_database, code, value_str) FROM stdin;
\.


--
-- Data for Name: r_database_contype; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_database_contype (id_database_contype, code, description) FROM stdin;
1	Native	Native (JDBC)
2	ODBC	ODBC
3	OCI	OCI
4	Plugin	Plugin specific access method
5	JNDI	JNDI
6	,	Custom
\.


--
-- Data for Name: r_database_type; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_database_type (id_database_type, code, description) FROM stdin;
1	DERBY	Apache Derby
2	AS/400	AS/400
3	AZURESQLDB	Azure SQL DB
4	INTERBASE	Borland Interbase
5	INFINIDB	Calpont InfiniDB
6	IMPALASIMBA	Cloudera Impala
7	DBASE	dBase III, IV or 5
8	EXASOL4	Exasol 4
9	EXTENDB	ExtenDB
10	FIREBIRD	Firebird SQL
11	GENERIC	Generic database
12	GOOGLEBIGQUERY	Google BigQuery
13	GREENPLUM	Greenplum
14	SQLBASE	Gupta SQL Base
15	H2	H2
16	HIVE	Hadoop Hive
17	HIVE2	Hadoop Hive 2/3
18	HIVEWAREHOUSE	Hive Warehouse Connector
19	HYPERSONIC	Hypersonic
20	DB2	IBM DB2
21	IMPALA	Impala
22	INFOBRIGHT	Infobright
23	INFORMIX	Informix
24	INGRES	Ingres
25	VECTORWISE	Ingres VectorWise
26	CACHE	Intersystems Cache
27	KINGBASEES	KingbaseES
28	LucidDB	LucidDB
29	MARIADB	MariaDB
30	SAPDB	MaxDB (SAP DB)
31	MONETDB	MonetDB
32	MSACCESS	MS Access
33	MSSQL	MS SQL Server
34	MSSQLNATIVE	MS SQL Server (Native)
35	MYSQL	MySQL
36	MONDRIAN	Native Mondrian
37	NEOVIEW	Neoview
38	NETEZZA	Netezza
39	ORACLE	Oracle
40	ORACLERDB	Oracle RDB
41	PALO	Palo MOLAP Server
42	KettleThin	Pentaho Data Services
43	POSTGRESQL	PostgreSQL
44	REDSHIFT	Redshift
45	REMEDY-AR-SYSTEM	Remedy Action Request System
46	SAPR3	SAP ERP System
47	SNOWFLAKEHV	Snowflake
48	SPARKSIMBA	SparkSQL
49	SQLITE	SQLite
50	SYBASE	Sybase
51	SYBASEIQ	SybaseIQ
52	TERADATA	Teradata
53	UNIVERSE	UniVerse database
54	VERTICA	Vertica
55	VERTICA5	Vertica 5+
\.


--
-- Data for Name: r_dependency; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_dependency (id_dependency, id_transformation, id_database, "TABLE_NAME", field_name) FROM stdin;
\.


--
-- Data for Name: r_directory; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_directory (id_directory, id_directory_parent, directory_name) FROM stdin;
1	0	examples
\.


--
-- Data for Name: r_element; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_element (id_element, id_element_type, "NAME") FROM stdin;
\.


--
-- Data for Name: r_element_attribute; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_element_attribute (id_element_attribute, id_element, id_element_attribute_parent, attr_key, attr_value) FROM stdin;
\.


--
-- Data for Name: r_element_type; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_element_type (id_element_type, id_namespace, "NAME", description) FROM stdin;
\.


--
-- Data for Name: r_job; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_job (id_job, id_directory, "NAME", description, extended_description, job_version, job_status, id_database_log, table_name_log, created_user, created_date, modified_user, modified_date, use_batch_id, pass_batch_id, use_logfield, shared_file) FROM stdin;
1	0	job_example	\N	\N	\N	0	-1	\N	-	2022-07-25 17:15:56.402	admin	2022-07-25 17:18:27.199	t	f	t	\N
\.


--
-- Data for Name: r_job_attribute; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_job_attribute (id_job_attribute, id_job, nr, code, value_num, value_str) FROM stdin;
1	1	0	LOG_SIZE_LIMIT	0	\N
2	1	0	JOB_LOG_TABLE_CONNECTION_NAME	0	\N
3	1	0	JOB_LOG_TABLE_SCHEMA_NAME	0	\N
4	1	0	JOB_LOG_TABLE_TABLE_NAME	0	\N
5	1	0	JOB_LOG_TABLE_TIMEOUT_IN_DAYS	0	\N
6	1	0	JOB_LOG_TABLE_FIELD_ID0	0	ID_JOB
7	1	0	JOB_LOG_TABLE_FIELD_NAME0	0	ID_JOB
8	1	0	JOB_LOG_TABLE_FIELD_ENABLED0	0	Y
9	1	0	JOB_LOG_TABLE_FIELD_ID1	0	CHANNEL_ID
10	1	0	JOB_LOG_TABLE_FIELD_NAME1	0	CHANNEL_ID
11	1	0	JOB_LOG_TABLE_FIELD_ENABLED1	0	Y
12	1	0	JOB_LOG_TABLE_FIELD_ID2	0	JOBNAME
13	1	0	JOB_LOG_TABLE_FIELD_NAME2	0	JOBNAME
14	1	0	JOB_LOG_TABLE_FIELD_ENABLED2	0	Y
15	1	0	JOB_LOG_TABLE_FIELD_ID3	0	STATUS
16	1	0	JOB_LOG_TABLE_FIELD_NAME3	0	STATUS
17	1	0	JOB_LOG_TABLE_FIELD_ENABLED3	0	Y
18	1	0	JOB_LOG_TABLE_FIELD_ID4	0	LINES_READ
19	1	0	JOB_LOG_TABLE_FIELD_NAME4	0	LINES_READ
20	1	0	JOB_LOG_TABLE_FIELD_ENABLED4	0	Y
21	1	0	JOB_LOG_TABLE_FIELD_ID5	0	LINES_WRITTEN
22	1	0	JOB_LOG_TABLE_FIELD_NAME5	0	LINES_WRITTEN
23	1	0	JOB_LOG_TABLE_FIELD_ENABLED5	0	Y
24	1	0	JOB_LOG_TABLE_FIELD_ID6	0	LINES_UPDATED
25	1	0	JOB_LOG_TABLE_FIELD_NAME6	0	LINES_UPDATED
26	1	0	JOB_LOG_TABLE_FIELD_ENABLED6	0	Y
27	1	0	JOB_LOG_TABLE_FIELD_ID7	0	LINES_INPUT
28	1	0	JOB_LOG_TABLE_FIELD_NAME7	0	LINES_INPUT
29	1	0	JOB_LOG_TABLE_FIELD_ENABLED7	0	Y
30	1	0	JOB_LOG_TABLE_FIELD_ID8	0	LINES_OUTPUT
31	1	0	JOB_LOG_TABLE_FIELD_NAME8	0	LINES_OUTPUT
32	1	0	JOB_LOG_TABLE_FIELD_ENABLED8	0	Y
33	1	0	JOB_LOG_TABLE_FIELD_ID9	0	LINES_REJECTED
34	1	0	JOB_LOG_TABLE_FIELD_NAME9	0	LINES_REJECTED
35	1	0	JOB_LOG_TABLE_FIELD_ENABLED9	0	Y
36	1	0	JOB_LOG_TABLE_FIELD_ID10	0	ERRORS
37	1	0	JOB_LOG_TABLE_FIELD_NAME10	0	ERRORS
38	1	0	JOB_LOG_TABLE_FIELD_ENABLED10	0	Y
39	1	0	JOB_LOG_TABLE_FIELD_ID11	0	STARTDATE
40	1	0	JOB_LOG_TABLE_FIELD_NAME11	0	STARTDATE
41	1	0	JOB_LOG_TABLE_FIELD_ENABLED11	0	Y
42	1	0	JOB_LOG_TABLE_FIELD_ID12	0	ENDDATE
43	1	0	JOB_LOG_TABLE_FIELD_NAME12	0	ENDDATE
44	1	0	JOB_LOG_TABLE_FIELD_ENABLED12	0	Y
45	1	0	JOB_LOG_TABLE_FIELD_ID13	0	LOGDATE
46	1	0	JOB_LOG_TABLE_FIELD_NAME13	0	LOGDATE
47	1	0	JOB_LOG_TABLE_FIELD_ENABLED13	0	Y
48	1	0	JOB_LOG_TABLE_FIELD_ID14	0	DEPDATE
49	1	0	JOB_LOG_TABLE_FIELD_NAME14	0	DEPDATE
50	1	0	JOB_LOG_TABLE_FIELD_ENABLED14	0	Y
51	1	0	JOB_LOG_TABLE_FIELD_ID15	0	REPLAYDATE
52	1	0	JOB_LOG_TABLE_FIELD_NAME15	0	REPLAYDATE
53	1	0	JOB_LOG_TABLE_FIELD_ENABLED15	0	Y
54	1	0	JOB_LOG_TABLE_FIELD_ID16	0	LOG_FIELD
55	1	0	JOB_LOG_TABLE_FIELD_NAME16	0	LOG_FIELD
56	1	0	JOB_LOG_TABLE_FIELD_ENABLED16	0	Y
57	1	0	JOB_LOG_TABLE_FIELD_ID17	0	EXECUTING_SERVER
58	1	0	JOB_LOG_TABLE_FIELD_NAME17	0	EXECUTING_SERVER
59	1	0	JOB_LOG_TABLE_FIELD_ENABLED17	0	N
60	1	0	JOB_LOG_TABLE_FIELD_ID18	0	EXECUTING_USER
61	1	0	JOB_LOG_TABLE_FIELD_NAME18	0	EXECUTING_USER
62	1	0	JOB_LOG_TABLE_FIELD_ENABLED18	0	N
63	1	0	JOB_LOG_TABLE_FIELD_ID19	0	START_JOB_ENTRY
64	1	0	JOB_LOG_TABLE_FIELD_NAME19	0	START_JOB_ENTRY
65	1	0	JOB_LOG_TABLE_FIELD_ENABLED19	0	N
66	1	0	JOB_LOG_TABLE_FIELD_ID20	0	CLIENT
67	1	0	JOB_LOG_TABLE_FIELD_NAME20	0	CLIENT
68	1	0	JOB_LOG_TABLE_FIELD_ENABLED20	0	N
69	1	0	JOBLOG_TABLE_INTERVAL	0	\N
70	1	0	JOBLOG_TABLE_SIZE_LIMIT	0	\N
71	1	0	JOB_ENTRY_LOG_TABLE_CONNECTION_NAME	0	\N
72	1	0	JOB_ENTRY_LOG_TABLE_SCHEMA_NAME	0	\N
73	1	0	JOB_ENTRY_LOG_TABLE_TABLE_NAME	0	\N
74	1	0	JOB_ENTRY_LOG_TABLE_TIMEOUT_IN_DAYS	0	\N
75	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID0	0	ID_BATCH
76	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME0	0	ID_BATCH
77	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED0	0	Y
78	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID1	0	CHANNEL_ID
79	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME1	0	CHANNEL_ID
80	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED1	0	Y
81	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID2	0	LOG_DATE
82	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME2	0	LOG_DATE
83	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED2	0	Y
84	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID3	0	JOBNAME
85	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME3	0	TRANSNAME
86	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED3	0	Y
87	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID4	0	JOBENTRYNAME
88	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME4	0	STEPNAME
89	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED4	0	Y
90	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID5	0	LINES_READ
91	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME5	0	LINES_READ
92	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED5	0	Y
93	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID6	0	LINES_WRITTEN
94	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME6	0	LINES_WRITTEN
95	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED6	0	Y
96	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID7	0	LINES_UPDATED
97	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME7	0	LINES_UPDATED
98	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED7	0	Y
99	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID8	0	LINES_INPUT
100	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME8	0	LINES_INPUT
101	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED8	0	Y
102	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID9	0	LINES_OUTPUT
103	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME9	0	LINES_OUTPUT
104	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED9	0	Y
105	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID10	0	LINES_REJECTED
106	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME10	0	LINES_REJECTED
107	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED10	0	Y
108	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID11	0	ERRORS
109	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME11	0	ERRORS
110	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED11	0	Y
111	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID12	0	RESULT
112	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME12	0	RESULT
113	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED12	0	Y
114	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID13	0	NR_RESULT_ROWS
115	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME13	0	NR_RESULT_ROWS
116	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED13	0	Y
117	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID14	0	NR_RESULT_FILES
118	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME14	0	NR_RESULT_FILES
119	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED14	0	Y
120	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID15	0	LOG_FIELD
121	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME15	0	LOG_FIELD
122	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED15	0	N
123	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ID16	0	COPY_NR
124	1	0	JOB_ENTRY_LOG_TABLE_FIELD_NAME16	0	COPY_NR
125	1	0	JOB_ENTRY_LOG_TABLE_FIELD_ENABLED16	0	N
126	1	0	CHANNEL_LOG_TABLE_CONNECTION_NAME	0	\N
127	1	0	CHANNEL_LOG_TABLE_SCHEMA_NAME	0	\N
128	1	0	CHANNEL_LOG_TABLE_TABLE_NAME	0	\N
129	1	0	CHANNEL_LOG_TABLE_TIMEOUT_IN_DAYS	0	\N
130	1	0	CHANNEL_LOG_TABLE_FIELD_ID0	0	ID_BATCH
131	1	0	CHANNEL_LOG_TABLE_FIELD_NAME0	0	ID_BATCH
132	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED0	0	Y
133	1	0	CHANNEL_LOG_TABLE_FIELD_ID1	0	CHANNEL_ID
134	1	0	CHANNEL_LOG_TABLE_FIELD_NAME1	0	CHANNEL_ID
135	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED1	0	Y
136	1	0	CHANNEL_LOG_TABLE_FIELD_ID2	0	LOG_DATE
137	1	0	CHANNEL_LOG_TABLE_FIELD_NAME2	0	LOG_DATE
138	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED2	0	Y
139	1	0	CHANNEL_LOG_TABLE_FIELD_ID3	0	LOGGING_OBJECT_TYPE
140	1	0	CHANNEL_LOG_TABLE_FIELD_NAME3	0	LOGGING_OBJECT_TYPE
141	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED3	0	Y
142	1	0	CHANNEL_LOG_TABLE_FIELD_ID4	0	OBJECT_NAME
143	1	0	CHANNEL_LOG_TABLE_FIELD_NAME4	0	OBJECT_NAME
144	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED4	0	Y
145	1	0	CHANNEL_LOG_TABLE_FIELD_ID5	0	OBJECT_COPY
146	1	0	CHANNEL_LOG_TABLE_FIELD_NAME5	0	OBJECT_COPY
147	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED5	0	Y
148	1	0	CHANNEL_LOG_TABLE_FIELD_ID6	0	REPOSITORY_DIRECTORY
149	1	0	CHANNEL_LOG_TABLE_FIELD_NAME6	0	REPOSITORY_DIRECTORY
150	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED6	0	Y
151	1	0	CHANNEL_LOG_TABLE_FIELD_ID7	0	FILENAME
152	1	0	CHANNEL_LOG_TABLE_FIELD_NAME7	0	FILENAME
153	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED7	0	Y
154	1	0	CHANNEL_LOG_TABLE_FIELD_ID8	0	OBJECT_ID
155	1	0	CHANNEL_LOG_TABLE_FIELD_NAME8	0	OBJECT_ID
156	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED8	0	Y
157	1	0	CHANNEL_LOG_TABLE_FIELD_ID9	0	OBJECT_REVISION
158	1	0	CHANNEL_LOG_TABLE_FIELD_NAME9	0	OBJECT_REVISION
159	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED9	0	Y
160	1	0	CHANNEL_LOG_TABLE_FIELD_ID10	0	PARENT_CHANNEL_ID
161	1	0	CHANNEL_LOG_TABLE_FIELD_NAME10	0	PARENT_CHANNEL_ID
162	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED10	0	Y
163	1	0	CHANNEL_LOG_TABLE_FIELD_ID11	0	ROOT_CHANNEL_ID
164	1	0	CHANNEL_LOG_TABLE_FIELD_NAME11	0	ROOT_CHANNEL_ID
165	1	0	CHANNEL_LOG_TABLE_FIELD_ENABLED11	0	Y
\.


--
-- Data for Name: r_job_hop; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_job_hop (id_job_hop, id_job, id_jobentry_copy_from, id_jobentry_copy_to, enabled, evaluation, unconditional) FROM stdin;
1	1	1	3	t	t	t
2	1	3	2	t	t	f
\.


--
-- Data for Name: r_job_lock; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_job_lock (id_job_lock, id_job, id_user, lock_message, lock_date) FROM stdin;
\.


--
-- Data for Name: r_job_note; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_job_note (id_job, id_note) FROM stdin;
\.


--
-- Data for Name: r_jobentry; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_jobentry (id_jobentry, id_job, id_jobentry_type, "NAME", description) FROM stdin;
1	1	69	Start	\N
2	1	73	Success	\N
3	1	86	Write to log	\N
\.


--
-- Data for Name: r_jobentry_attribute; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_jobentry_attribute (id_jobentry_attribute, id_job, id_jobentry, nr, code, value_num, value_str) FROM stdin;
1	1	1	0	start	0.00	Y
2	1	1	0	dummy	0.00	N
3	1	1	0	repeat	0.00	N
4	1	1	0	schedulerType	0.00	\N
5	1	1	0	intervalSeconds	0.00	\N
6	1	1	0	intervalMinutes	60.00	\N
7	1	1	0	hour	12.00	\N
8	1	1	0	minutes	0.00	\N
9	1	1	0	weekDay	1.00	\N
10	1	1	0	dayOfMonth	1.00	\N
11	1	3	0	logmessage	0.00	this is a log by Example Job
12	1	3	0	loglevel	0.00	Basic
13	1	3	0	logsubject	0.00	example Job
\.


--
-- Data for Name: r_jobentry_copy; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_jobentry_copy (id_jobentry_copy, id_jobentry, id_job, id_jobentry_type, nr, gui_location_x, gui_location_y, gui_draw, parallel) FROM stdin;
1	1	1	69	0	160	112	t	f
2	2	1	73	0	576	224	t	f
3	3	1	86	0	336	160	t	f
\.


--
-- Data for Name: r_jobentry_database; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_jobentry_database (id_job, id_jobentry, id_database) FROM stdin;
\.


--
-- Data for Name: r_jobentry_type; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_jobentry_type (id_jobentry_type, code, description) FROM stdin;
1	ABORT	Abort job
2	ADD_RESULT_FILENAMES	Add filenames to result
3	EMRJobExecutorPlugin	Amazon EMR job executor
4	HiveJobExecutorPlugin	Amazon Hive job executor
5	DataRefineryBuildModel	Build model
6	MYSQL_BULK_FILE	Bulk load from MySQL into file
7	MSSQL_BULK_LOAD	Bulk load into MSSQL
8	MYSQL_BULK_LOAD	Bulk load into MySQL
9	CHECK_DB_CONNECTIONS	Check DB connections
10	CHECK_FILES_LOCKED	Check files locked
11	FOLDER_IS_EMPTY	Check if a folder is empty
12	CONNECTED_TO_REPOSITORY	Check if connected to repository
13	XML_WELL_FORMED	Check if XML file is well formed
14	WEBSERVICE_AVAILABLE	Check webservice availability
15	FILES_EXIST	Checks if files exist
16	COLUMNS_EXIST	Columns exist in a table
17	FOLDERS_COMPARE	Compare folders
18	DOS_UNIX_CONVERTER	Convert file between Windows and Unix
19	COPY_FILES	Copy files
20	CREATE_FOLDER	Create a folder
21	CREATE_FILE	Create file
22	PGP_DECRYPT_FILES	Decrypt files with PGP
23	DELETE_FILE	Delete file
24	DELETE_RESULT_FILENAMES	Delete filenames from result
25	DELETE_FILES	Delete files
26	DELETE_FOLDERS	Delete folders
27	MSGBOX_INFO	Display msgbox info
28	DTD_VALIDATOR	DTD validator
29	PGP_ENCRYPT_FILES	Encrypt files with PGP
30	EVAL_FILES_METRICS	Evaluate files metrics
31	EVAL_TABLE_CONTENT	Evaluate rows number in a table
32	DummyJob	Example job (deprecated)
33	EXPORT_REPOSITORY	Export repository to XML file
34	FILE_COMPARE	File compare
35	FILE_EXISTS	File exists
36	FTP_DELETE	FTP delete
37	FTP	Get a file with FTP
38	FTPS_GET	Get a file with FTPS
39	SFTP	Get a file with SFTP
40	GET_POP	Get mails (POP3/IMAP)
41	HadoopCopyFilesPlugin	Hadoop copy files
42	HadoopJobExecutorPlugin	Hadoop job executor 
43	HL7MLLPAcknowledge	HL7 MLLP acknowledge
44	HL7MLLPInput	HL7 MLLP input
45	HTTP	HTTP
46	EVAL	JavaScript
47	JOB	Job
48	MAIL	Mail
49	MAIL_VALIDATOR	Mail validator
50	MOVE_FILES	Move files
51	MS_ACCESS_BULK_LOAD	MS Access bulk load (deprecated)
52	OozieJobExecutor	Oozie job executor
53	PALO_CUBE_CREATE	Palo cube create (deprecated)
54	PALO_CUBE_DELETE	Palo cube delete (deprecated)
55	HadoopTransJobExecutorPlugin	Pentaho MapReduce
56	HadoopPigScriptExecutorPlugin	Pig script executor
57	PING	Ping a host
58	COPY_MOVE_RESULT_FILENAMES	Process result filenames
59	DATASOURCE_PUBLISH	Publish model
60	FTP_PUT	Put a file with FTP
61	SFTPPUT	Put a file with SFTP
62	SYSLOG	Send information using syslog
63	SEND_NAGIOS_PASSIVE_CHECK	Send Nagios passive check
64	SNMP_TRAP	Send SNMP trap
65	SET_VARIABLES	Set variables
66	SHELL	Shell
67	SIMPLE_EVAL	Simple evaluation
68	SparkSubmit	Spark submit
69	SPECIAL	Special entries
70	SQL	SQL
71	SqoopExport	Sqoop export
72	SqoopImport	Sqoop import
73	SUCCESS	Success
74	TABLE_EXISTS	Table exists
75	TALEND_JOB_EXEC	Talend job execution (deprecated)
76	TELNET	Telnet a host
77	TRANS	Transformation
78	TRUNCATE_TABLES	Truncate tables
79	UNZIP	Unzip file
80	FTPS_PUT	Upload files to FTPS
81	PGP_VERIFY_FILES	Verify file signature with PGP
82	DELAY	Wait for
83	WAIT_FOR_FILE	Wait for file
84	WAIT_FOR_SQL	Wait for SQL
85	WRITE_TO_FILE	Write to file
86	WRITE_TO_LOG	Write to log
87	XSD_VALIDATOR	XSD validator
88	XSLT	XSL transformation
89	ZIP_FILE	Zip file
\.


--
-- Data for Name: r_log; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_log (id_log, "NAME", id_loglevel, logtype, filename, fileextention, add_date, add_time, id_database_log, table_name_log) FROM stdin;
\.


--
-- Data for Name: r_loglevel; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_loglevel (id_loglevel, code, description) FROM stdin;
1	Error	Error
2	Minimal	Minimal
3	Basic	Basic
4	Detailed	Detailed
5	Debug	Debug
6	Rowlevel	Row Level (very detailed)
\.


--
-- Data for Name: r_namespace; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_namespace (id_namespace, "NAME") FROM stdin;
\.


--
-- Data for Name: r_note; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_note (id_note, value_str, gui_location_x, gui_location_y, gui_location_width, gui_location_height, font_name, font_size, font_bold, font_italic, font_color_red, font_color_green, font_color_blue, font_back_ground_color_red, font_back_ground_color_green, font_back_ground_color_blue, font_border_color_red, font_border_color_green, font_border_color_blue, draw_shadow) FROM stdin;
\.


--
-- Data for Name: r_partition; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_partition (id_partition, id_partition_schema, partition_id) FROM stdin;
\.


--
-- Data for Name: r_partition_schema; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_partition_schema (id_partition_schema, "NAME", dynamic_definition, partitions_per_slave) FROM stdin;
\.


--
-- Data for Name: r_repository_log; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_repository_log (id_repository_log, rep_version, log_date, log_user, operation_desc) FROM stdin;
2	5.0	2022-07-25 17:15:19.731	admin	Creation of the Kettle repository
3	5.0	2022-07-25 17:16:56.028	admin	save job 'job_example'
4	5.0	2022-07-25 17:18:27.282	admin	save job 'job_example'
\.


--
-- Data for Name: r_slave; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_slave (id_slave, "NAME", host_name, port, web_app_name, username, "PASSWORD", proxy_host_name, proxy_port, non_proxy_hosts, master) FROM stdin;
\.


--
-- Data for Name: r_step; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_step (id_step, id_transformation, "NAME", description, id_step_type, distribute, copies, gui_location_x, gui_location_y, gui_draw, copies_string) FROM stdin;
\.


--
-- Data for Name: r_step_attribute; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_step_attribute (id_step_attribute, id_transformation, id_step, nr, code, value_num, value_str) FROM stdin;
\.


--
-- Data for Name: r_step_database; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_step_database (id_transformation, id_step, id_database) FROM stdin;
\.


--
-- Data for Name: r_step_type; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_step_type (id_step_type, code, description, helptext) FROM stdin;
1	Abort	Abort	Abort a transformation
2	CheckSum	Add a checksum	Add a checksum column for each input row
3	Constant	Add constants	Add one or more constants to the input rows
4	Sequence	Add sequence	Get the next value from an sequence
5	FieldsChangeSequence	Add value fields changing sequence	Add sequence depending of fields value change.\nEach time value of at least one field change, PDI will reset sequence.
6	AddXML	Add XML	Encode several fields into an XML fragment
7	AnalyticQuery	Analytic query	Execute analytic queries over a sorted dataset (LEAD/LAG/FIRST/LAST)
8	FieldMetadataAnnotation	Annotate stream	Add more details to describe data for published models used by the Streamlined Data Refinery.
9	Append	Append streams	Append 2 streams in an ordered way
10	AutoDoc	Automatic documentation output	This step automatically generates documentation based on input in the form of a list of transformations and jobs
11	AvroInputNew	Avro input	Reads data from Avro file
12	AvroInput	Avro input (deprecated)	Reads data from an Avro file
13	AvroOutput	Avro output	Writes data to an Avro file according to a mapping
14	BlockUntilStepsFinish	Block this step until steps finish	Block this step until selected steps finish.
15	BlockingStep	Blocking step	The Blocking step blocks all output until the very last row is received from the previous step.
16	Calculator	Calculator	Create new fields by performing simple calculations
17	DBProc	Call DB procedure	Get back information by calling a database procedure.
18	CallEndpointStep	Call endpoint	Call an endpoint of the Pentaho Server.
19	CassandraInput	Cassandra input	Reads data from a Cassandra table
20	CassandraOutput	Cassandra output	Writes to a Cassandra table
21	ChangeFileEncoding	Change file encoding	Change file encoding and create a new file
22	FileLocked	Check if file is locked	Check if a file is locked by another process
23	WebServiceAvailable	Check if webservice is available	Check if a webservice is available
24	CloneRow	Clone row	Clone a row as many times as needed
25	ClosureGenerator	Closure generator	This step allows you to generates a closure table using parent-child relationships.
26	ColumnExists	Column exists	Check if a column exists
27	CombinationLookup	Combination lookup/update	Update a junk dimension in a data warehouse.\nAlternatively, look up information in this dimension.\nThe primary key of a junk dimension are all the fields.
28	ConcatFields	Concat fields	Concat fields together into a new field (similar to the Text File Output step)
29	RowsToResult	Copy rows to result	Use this step to write rows to the executing job.\nThe information will then be passed to the next entry in this job.
30	CouchDbInput	CouchDB input	Reads from a Couch DB view
31	CreditCardValidator	Credit card validator	The Credit card validator step will help you tell:\n(1) if a credit card number is valid (uses LUHN10 (MOD-10) algorithm)\n(2) which credit card vendor handles that number\n(VISA, MasterCard, Diners Club, EnRoute, American Express (AMEX),...)
32	CsvInput	CSV file input	Simple CSV file input
33	DataGrid	Data grid	Enter rows of static data in a grid, usually for testing, reference or demo purpose
34	Validator	Data validator	Validates passing data based on a set of rules
35	DBJoin	Database join	Execute a database query using stream values as parameters
36	DBLookup	Database lookup	Look up values in a database using field values
37	CubeInput	De-serialize from file	Read rows of data from a data cube.
38	Delay	Delay row	Output each input row after a delay
39	Delete	Delete	Delete data in a database table based upon keys
40	DetectEmptyStream	Detect empty stream	This step will output one empty row if input stream is empty\n(ie when input stream does not contain any row)
41	DimensionLookup	Dimension lookup/update	Update a slowly changing dimension in a data warehouse.\nAlternatively, look up information in this dimension.
42	Dummy	Dummy (do nothing)	This step type doesn't do anything.\nIt's useful however when testing things or in certain situations where you want to split streams.
43	DynamicSQLRow	Dynamic SQL row	Execute dynamic SQL statement build in a previous field
44	TypeExitEdi2XmlStep	EDI to XML	Converts Edi text to generic XML
45	ElasticSearchBulk	Elasticsearch bulk insert (deprecated)	Performs bulk inserts into ElasticSearch
46	MailInput	Email messages input	Read POP3/IMAP server and retrieve messages
47	ShapeFileReader	ESRI shapefile reader	Reads shape file data from an ESRI shape file and linked DBF file
48	MetaInject	ETL metadata injection	ETL metadata injection
49	DummyStep	Example step (deprecated)	This is a plugin example step
50	ExecProcess	Execute a process	Execute a process and return the result
51	ExecSQLRow	Execute row SQL script	Execute SQL script extracted from a field\ncreated in a previous step.
52	ExecSQL	Execute SQL script	Execute an SQL script, optionally parameterized using input rows
53	FileExists	File exists	Check if a file exists
54	FilterRows	Filter rows	Filter rows using simple equations
55	FixedInput	Fixed file input	Fixed file input
56	Formula	Formula	Calculate a formula using Pentaho's libformula
57	FuzzyMatch	Fuzzy match	Finding approximate matches to a string using matching algorithms.\nRead a field from a main stream and output approximative value from lookup stream.
58	RandomCCNumberGenerator	Generate random credit card numbers	Generate random valide (luhn check) credit card numbers
59	RandomValue	Generate random value	Generate random value
60	RowGenerator	Generate rows	Generate a number of empty or equal rows.
61	getXMLData	Get data from XML	Get data from XML file by using XPath.\n This step also allows you to parse XML defined in a previous field.
62	GetFileNames	Get file names	Get file names from the operating system and send them to the next step.
63	FilesFromResult	Get files from result	This step allows you to read filenames used or generated in a previous entry in a job.
64	GetFilesRowsCount	Get files rows count	Returns rows count for text files.
65	GetSlaveSequence	Get ID from slave server	Retrieves unique IDs in blocks from a slave server.  The referenced sequence needs to be configured on the slave server in the XML configuration file.
66	RecordsFromStream	Get records from stream	This step allows you to read records from a streaming step.
67	GetRepositoryNames	Get repository names	Lists detailed information about transformations and/or jobs in a repository
68	RowsFromResult	Get rows from result	This allows you to read rows from a previous entry in a job.
69	GetSessionVariableStep	Get session variables	Get session variables from the current user session.
70	GetSubFolders	Get subfolder names	Read a parent folder and return all subfolders
71	SystemInfo	Get system info	Get information from the system like system date, arguments, etc.
72	GetTableNames	Get table names	Get table names from database connection and send them to the next step
73	GetVariable	Get variables	Determine the values of certain (environment or Kettle) variables and put them in field values.
74	TypeExitGoogleAnalyticsInputStep	Google Analytics	Fetches data from google analytics account
75	GPBulkLoader	Greenplum bulk loader (deprecated)	Greenplum bulk loader
76	GPLoad	Greenplum load	Greenplum load
77	GroupBy	Group by	Builds aggregates in a group by fashion.\nThis works only on a sorted input.\nIf the input is not sorted, only double consecutive rows are handled correctly.
78	ParallelGzipCsvInput	GZIP CSV input	Parallel GZIP CSV file input reader
79	HadoopFileInputPlugin	Hadoop file input	Process files from an HDFS location
80	HadoopFileOutputPlugin	Hadoop file output	Create files in an HDFS location 
81	HBaseInput	HBase input	Reads data from a HBase table according to a mapping 
82	HBaseOutput	HBase output	Writes data to an HBase table according to a mapping
83	HBaseRowDecoder	HBase row decoder	Decodes an incoming key and HBase result object according to a mapping 
84	HL7Input	HL7 input	Reads and parses HL7 messages and outputs a series of values from the messages
85	HTTP	HTTP client	Call a web service over HTTP by supplying a base URL by allowing parameters to be set dynamically
86	HTTPPOST	HTTP post	Call a web service request over HTTP by supplying a base URL by allowing parameters to be set dynamically
87	DetectLastRow	Identify last row in a stream	Last row will be marked
88	IfNull	If field value is null	Sets a field value to a constant if it is null.
89	InfobrightOutput	Infobright loader	Load data to an Infobright database table
90	VectorWiseBulkLoader	Ingres VectorWise bulk loader	This step interfaces with the Ingres VectorWise Bulk Loader "COPY TABLE" command.
91	Injector	Injector	Injector step to allow to inject rows into the transformation through the java API
92	InsertUpdate	Insert / update	Update or insert rows in a database based upon keys.
93	JavaFilter	Java filter	Filter rows using java code
94	Jms2Consumer	JMS consumer	Consumes JMS streams
95	Jms2Producer	JMS producer	Produces JMS streams
96	JobExecutor	Job executor	This step executes a Pentaho Data Integration job, sets parameters and passes rows.
97	JoinRows	Join rows (cartesian product)	The output of this step is the cartesian product of the input streams.\nThe number of rows is the multiplication of the number of rows in the input streams.
98	JsonInput	JSON input	Extract relevant portions out of JSON structures (file or incoming field) and output rows
99	JsonOutput	JSON output	Create JSON block and output it in a field or a file.
100	KafkaConsumerInput	Kafka consumer	Consume messages from a Kafka topic
101	KafkaProducerOutput	Kafka producer	Produce messages to a Kafka topic
102	LDAPInput	LDAP input	Read data from LDAP host
103	LDAPOutput	LDAP output	Perform Insert, upsert, update, add or delete operations on records based on their DN (Distinguished  Name).
104	LDIFInput	LDIF input	Read data from LDIF files
105	LoadFileInput	Load file content in memory	Load file content in memory
106	LucidDBStreamingLoader	LucidDB streaming loader (deprecated)	Load data into LucidDB by using Remote Rows UDX.
107	Mail	Mail	Send eMail.
108	MailValidator	Mail validator	Check if an email address is valid.
109	Mapping	Mapping (sub-transformation)	Run a mapping (sub-transformation), use MappingInput and MappingOutput to specify the fields interface
110	MappingInput	Mapping input specification	Specify the input interface of a mapping
111	MappingOutput	Mapping output specification	Specify the output interface of a mapping
112	HadoopEnterPlugin	MapReduce input	Enter a Hadoop Mapper or Reducer transformation
113	HadoopExitPlugin	MapReduce output	Exit a Hadoop Mapper or Reducer transformation 
114	MemoryGroupBy	Memory group by	Builds aggregates in a group by fashion.\nThis step doesn't require sorted input.
115	MergeJoin	Merge join	Joins two streams on a given key and outputs a joined set. The input streams must be sorted on the join key
116	MergeRows	Merge rows (diff)	Merge two streams of rows, sorted on a certain key.  The two streams are compared and the equals, changed, deleted and new rows are flagged.
117	StepMetastructure	Metadata structure of stream	This is a step to read the metadata of the incoming stream.
118	AccessInput	Microsoft Access input	Read data from a Microsoft Access file
119	AccessOutput	Microsoft Access output	Stores records into an MS-Access database table.
120	ExcelInput	Microsoft Excel input	Read data from Excel and OpenOffice Workbooks (XLS, XLSX, ODS).
121	ExcelOutput	Microsoft Excel output	Stores records into an Excel (XLS) document with formatting information.
122	TypeExitExcelWriterStep	Microsoft Excel writer	Writes or appends data to an Excel file
123	ScriptValueMod	Modified JavaScript value	This is a modified plugin for the Scripting Values with improved interface and performance.\nWritten & donated to open source by Martin Lange, Proconis : http://www.proconis.de
124	MondrianInput	Mondrian input	Execute and retrieve data using an MDX query against a Pentaho Analyses OLAP server (Mondrian)
125	MonetDBAgileMart	MonetDB Agile Mart	Load data into MonetDB for Agile BI use cases
126	MonetDBBulkLoader	MonetDB bulk loader	Load data into MonetDB by using their bulk load command in streaming mode.
127	MongoDbInput	MongoDB input	Reads from a Mongo DB collection
128	MongoDbOutput	MongoDB output	Writes to a Mongo DB collection
129	MQTTConsumer	MQTT consumer	Subscribes and streams an MQTT Topic
130	MQTTProducer	MQTT producer	Produce messages to a MQTT Topic
131	MultiwayMergeJoin	Multiway merge join	Multiway merge join
132	MySQLBulkLoader	MySQL bulk loader	MySQL bulk loader step, loading data over a named pipe (not available on MS Windows)
133	NullIf	Null if	Sets a field value to null if it is equal to a constant value
134	NumberRange	Number range	Create ranges based on numeric field
135	OlapInput	OLAP input	Execute and retrieve data using an MDX query against any XML/A OLAP datasource using olap4j
136	OraBulkLoader	Oracle bulk loader	Use Oracle bulk loader to load data
137	OrcInput	ORC input	Reads data from ORC file
138	OrcOutput	ORC output	Writes data to an Orc file according to a mapping
139	StepsMetrics	Output steps metrics	Return metrics for one or several steps
140	PaloCellInput	Palo cell input (deprecated)	Reads data from a defined Palo Cube 
141	PaloCellOutput	Palo cell output (deprecated)	Writes data to a defined Palo Cube
142	PaloDimInput	Palo dim input (deprecated)	Reads data from a defined Palo Dimension
143	PaloDimOutput	Palo dim output (deprecated)	Writes data to defined Palo Dimension
144	ParquetInput	Parquet input	Reads data from a Parquet file.
145	ParquetOutput	Parquet output	Writes data to a Parquet file according to a mapping.
146	PentahoReportingOutput	Pentaho reporting output	Executes an existing report (PRPT)
147	PGPDecryptStream	PGP decrypt stream	Decrypt data stream with PGP
148	PGPEncryptStream	PGP encrypt stream	Encrypt data stream with PGP
149	PGBulkLoader	PostgreSQL bulk loader	PostgreSQL Bulk Loader
150	PrioritizeStreams	Prioritize streams	Prioritize streams in an order way.
151	ProcessFiles	Process files	Process one file per row (copy or move or delete).\nThis step only accept filename in input.
152	PropertyOutput	Properties output	Write data to properties file
153	PropertyInput	Property input	Read data (key, value) from properties files.
154	RegexEval	Regex evaluation	Regular expression Evaluation\nThis step uses a regular expression to evaluate a field. It can also extract new fields out of an existing field with capturing groups.
155	ReplaceString	Replace in string	Replace all occurences a word in a string with another word.
156	ReservoirSampling	Reservoir sampling	[Transform] Samples a fixed number of rows from the incoming stream
157	Rest	REST client	Consume RESTfull services.\nREpresentational State Transfer (REST) is a key design idiom that embraces a stateless client-server\narchitecture in which the web services are viewed as resources and can be identified by their URLs
158	Denormaliser	Row denormaliser	Denormalises rows by looking up key-value pairs and by assigning them to new fields in the output rows.\nThis method aggregates and needs the input rows to be sorted on the grouping fields
159	Flattener	Row flattener	Flattens consecutive rows based on the order in which they appear in the input stream
160	Normaliser	Row normaliser	De-normalised information can be normalised using this step type.
161	RssInput	RSS input	Read RSS feeds
162	RssOutput	RSS output	Read RSS stream.
163	RuleAccumulator	Rules accumulator	Rules accumulator step
164	RuleExecutor	Rules executor	Rules executor step
165	SSH	Run SSH commands	Run SSH commands and returns result.
166	S3CSVINPUT	S3 CSV input	Is capable of reading CSV data stored on Amazon S3 in parallel
167	S3FileOutputPlugin	S3 file output	Create files in an S3 location
168	SalesforceDelete	Salesforce delete	Delete records in Salesforce module.
169	SalesforceInput	Salesforce input	Extract data from Salesforce
170	SalesforceInsert	Salesforce insert	Insert records in Salesforce module.
171	SalesforceUpdate	Salesforce update	Update records in Salesforce module.
172	SalesforceUpsert	Salesforce upsert	Insert or update records in Salesforce module.
173	SampleRows	Sample rows	Filter rows based on the line number.
174	SAPINPUT	SAP input (deprecated)	Read data from SAP ERP, optionally with parameters
175	SASInput	SAS input	This step reads files in sas7bdat (SAS) native format
176	Script	Script (deprecated)	Calculate values by scripting in Ruby, Python, Groovy, JavaScript, ... (JSR-223)
177	SecretKeyGenerator	Secret key generator	Generate secret key for algorithms such as DES, AES, TripleDES.
178	SelectValues	Select values	Select or remove fields in a row.\nOptionally, set the field meta-data: type, length and precision.
179	SyslogMessage	Send message to syslog	Send message to syslog server
180	CubeOutput	Serialize to file	Write rows of data to a data cube
181	SetValueField	Set field value	Set value of a field with another value field
182	SetValueConstant	Set field value to a constant	Set value of a field to a constant
183	FilesToResult	Set files in result	This step allows you to set filenames in the result of this transformation.\nSubsequent job entries can then use this information.
184	SetSessionVariableStep	Set session variables	Set session variables in the current user session.
185	SetVariable	Set variables	Set environment variables based on a single input row.
186	SFTPPut	SFTP put	Upload a file or a stream file to remote host via SFTP
187	CreateSharedDimensions	Shared dimension	Create shared dimensions for use with Streamlined Data Refinery.
188	SimpleMapping	Simple mapping (sub-transformation)	Run a mapping (sub-transformation), use MappingInput and MappingOutput to specify the fields interface.  This is the simplified version only allowing one input and one output data set.
189	SingleThreader	Single threader	Executes a transformation snippet in a single thread.  You need a standard mapping or a transformation with an Injector step where data from the parent transformation will arive in blocks.
190	SocketReader	Socket reader	Socket reader.  A socket client that connects to a server (Socket Writer step).
191	SocketWriter	Socket writer	Socket writer.  A socket server that can send rows of data to a socket reader.
192	SortRows	Sort rows	Sort rows based upon field values (ascending or descending)
193	SortedMerge	Sorted merge	Sorted merge
194	SplitFieldToRows3	Split field to rows	Splits a single string field by delimiter and creates a new row for each split term
195	FieldSplitter	Split fields	When you want to split a single field into more then one, use this step type.
196	SQLFileOutput	SQL file output	Output SQL INSERT statements to file
197	SSTableOutput	SSTable output	Writes to a filesystem directory as a Cassandra SSTable
198	StreamLookup	Stream lookup	Look up values coming from another stream in the transformation.
199	StringOperations	String operations	Apply certain operations like trimming, padding and others to string value.
200	StringCut	Strings cut	Strings cut (substring).
201	SwitchCase	Switch / case	Switch a row to a certain target step based on the case value in a field.
202	SymmetricCryptoTrans	Symmetric cryptography	Encrypt or decrypt a string using symmetric encryption.\nAvailable algorithms are DES, AES, TripleDES.
203	SynchronizeAfterMerge	Synchronize after merge	This step perform insert/update/delete in one go based on the value of a field.
204	TableAgileMart	Table Agile Mart	Load data into a table for Agile BI use cases
205	TableCompare	Table compare	Compares 2 tables and gives back a list of differences
206	TableExists	Table exists	Check if a table exists on a specified connection
207	TableInput	Table input	Read information from a database table.
208	TableOutput	Table output	Write information to a database table
209	TeraFast	Teradata Fastload bulk loader	The Teradata Fastload bulk loader
210	TeraDataBulkLoader	Teradata TPT bulk loader	Teradata TPT bulkloader, using tbuild command
211	TextFileInput	Text file input	Read data from a text file in several formats.\nThis data can then be passed on to the next step(s)...
212	OldTextFileInput	Text file input (deprecated)	Read data from a text file in several formats.\nThis data can then be passed on to the next step(s)...
213	TextFileOutput	Text file output	Write rows to a text file.
214	TextFileOutputLegacy	Text file output (deprecated)	Write rows to a text file.
215	TransExecutor	Transformation executor	This step executes a Pentaho Data Integration transformation, sets parameters and passes rows.
216	Unique	Unique rows	Remove double rows and leave only unique occurrences.\nThis works only on a sorted input.\nIf the input is not sorted, only double consecutive rows are handled correctly.
217	UniqueRowsByHashSet	Unique rows (HashSet)	Remove double rows and leave only unique occurrences by using a HashSet.
218	UnivariateStats	Univariate statistics	This step computes some simple stats based on a single input field
219	Update	Update	Update data in a database table based upon keys
220	UserDefinedJavaClass	User defined Java class	This step allows you to program a step using Java code
221	Janino	User defined Java expression	Calculate the result of a Java Expression using Janino
222	ValueMapper	Value mapper	Maps values of a certain field from one value to another
223	VerticaBulkLoader	Vertica bulk loader	Bulk load data into a Vertica database table
224	WebServiceLookup	Web services lookup	Look up information using web services (WSDL)
225	WriteToLog	Write to log	Write data to log
226	XBaseInput	XBase input	Reads records from an XBase type of database file (DBF)
227	XMLInputStream	XML input stream (StAX)	This step is capable of processing very large and complex XML files very fast.
228	XMLJoin	XML join	Joins a stream of XML-Tags into a target XML string
229	XMLOutput	XML output	Write data to an XML file
230	XSDValidator	XSD validator	Validate XML source (files or streams) against XML Schema Definition.
231	XSLT	XSL transformation	Make an XSL transformation
232	YamlInput	YAML input 	Read YAML source (file or stream) parse them and convert them to rows and writes these to one or more output.
233	ZipFile	Zip file	Zip a file.\nFilename will be extracted from incoming stream.
\.


--
-- Data for Name: r_trans_attribute; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_attribute (id_trans_attribute, id_transformation, nr, code, value_num, value_str) FROM stdin;
\.


--
-- Data for Name: r_trans_cluster; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_cluster (id_trans_cluster, id_transformation, id_cluster) FROM stdin;
\.


--
-- Data for Name: r_trans_hop; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_hop (id_trans_hop, id_transformation, id_step_from, id_step_to, enabled) FROM stdin;
\.


--
-- Data for Name: r_trans_lock; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_lock (id_trans_lock, id_transformation, id_user, lock_message, lock_date) FROM stdin;
\.


--
-- Data for Name: r_trans_note; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_note (id_transformation, id_note) FROM stdin;
\.


--
-- Data for Name: r_trans_partition_schema; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_partition_schema (id_trans_partition_schema, id_transformation, id_partition_schema) FROM stdin;
\.


--
-- Data for Name: r_trans_slave; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_slave (id_trans_slave, id_transformation, id_slave) FROM stdin;
\.


--
-- Data for Name: r_trans_step_condition; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_trans_step_condition (id_transformation, id_step, id_condition) FROM stdin;
\.


--
-- Data for Name: r_transformation; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_transformation (id_transformation, id_directory, "NAME", description, extended_description, trans_version, trans_status, id_step_read, id_step_write, id_step_input, id_step_output, id_step_update, id_database_log, table_name_log, use_batchid, use_logfield, id_database_maxdate, table_name_maxdate, field_name_maxdate, offset_maxdate, diff_maxdate, created_user, created_date, modified_user, modified_date, size_rowset) FROM stdin;
\.


--
-- Data for Name: r_user; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_user (id_user, "LOGIN", "PASSWORD", "NAME", description, enabled) FROM stdin;
1	admin	2be98afc86aa7f2e4cb79ce71da9fa6d4	Administrator	User manager	t
2	guest	2be98afc86aa7f2e4cb79ce77cb97bcce	Guest account	Read-only guest account	t
\.


--
-- Data for Name: r_value; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_value (id_value, "NAME", value_type, value_str, is_null) FROM stdin;
\.


--
-- Data for Name: r_version; Type: TABLE DATA; Schema: public; Owner: rossonet
--

COPY public.r_version (id_version, major_version, minor_version, upgrade_date, is_upgrade) FROM stdin;
1	5	0	2022-07-25 17:15:19.742	f
\.


--
-- Name: r_cluster_id_cluster_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_cluster_id_cluster_seq', 1, false);


--
-- Name: r_cluster_slave_id_cluster_slave_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_cluster_slave_id_cluster_slave_seq', 1, false);


--
-- Name: r_condition_id_condition_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_condition_id_condition_seq', 1, false);


--
-- Name: r_database_attribute_id_database_attribute_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_database_attribute_id_database_attribute_seq', 1, false);


--
-- Name: r_database_contype_id_database_contype_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_database_contype_id_database_contype_seq', 1, false);


--
-- Name: r_database_id_database_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_database_id_database_seq', 1, false);


--
-- Name: r_database_type_id_database_type_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_database_type_id_database_type_seq', 1, false);


--
-- Name: r_dependency_id_dependency_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_dependency_id_dependency_seq', 1, false);


--
-- Name: r_directory_id_directory_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_directory_id_directory_seq', 1, false);


--
-- Name: r_element_attribute_id_element_attribute_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_element_attribute_id_element_attribute_seq', 1, false);


--
-- Name: r_element_id_element_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_element_id_element_seq', 1, false);


--
-- Name: r_element_type_id_element_type_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_element_type_id_element_type_seq', 1, false);


--
-- Name: r_job_attribute_id_job_attribute_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_job_attribute_id_job_attribute_seq', 1, false);


--
-- Name: r_job_hop_id_job_hop_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_job_hop_id_job_hop_seq', 1, false);


--
-- Name: r_job_id_job_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_job_id_job_seq', 1, false);


--
-- Name: r_job_lock_id_job_lock_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_job_lock_id_job_lock_seq', 1, false);


--
-- Name: r_jobentry_attribute_id_jobentry_attribute_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_jobentry_attribute_id_jobentry_attribute_seq', 1, false);


--
-- Name: r_jobentry_copy_id_jobentry_copy_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_jobentry_copy_id_jobentry_copy_seq', 1, false);


--
-- Name: r_jobentry_id_jobentry_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_jobentry_id_jobentry_seq', 1, false);


--
-- Name: r_jobentry_type_id_jobentry_type_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_jobentry_type_id_jobentry_type_seq', 1, false);


--
-- Name: r_log_id_log_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_log_id_log_seq', 1, false);


--
-- Name: r_loglevel_id_loglevel_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_loglevel_id_loglevel_seq', 1, false);


--
-- Name: r_namespace_id_namespace_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_namespace_id_namespace_seq', 1, false);


--
-- Name: r_note_id_note_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_note_id_note_seq', 1, false);


--
-- Name: r_partition_id_partition_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_partition_id_partition_seq', 1, false);


--
-- Name: r_partition_schema_id_partition_schema_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_partition_schema_id_partition_schema_seq', 1, false);


--
-- Name: r_repository_log_id_repository_log_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_repository_log_id_repository_log_seq', 1, false);


--
-- Name: r_slave_id_slave_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_slave_id_slave_seq', 1, false);


--
-- Name: r_step_attribute_id_step_attribute_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_step_attribute_id_step_attribute_seq', 1, false);


--
-- Name: r_step_id_step_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_step_id_step_seq', 1, false);


--
-- Name: r_step_type_id_step_type_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_step_type_id_step_type_seq', 1, false);


--
-- Name: r_trans_attribute_id_trans_attribute_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_trans_attribute_id_trans_attribute_seq', 1, false);


--
-- Name: r_trans_cluster_id_trans_cluster_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_trans_cluster_id_trans_cluster_seq', 1, false);


--
-- Name: r_trans_hop_id_trans_hop_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_trans_hop_id_trans_hop_seq', 1, false);


--
-- Name: r_trans_lock_id_trans_lock_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_trans_lock_id_trans_lock_seq', 1, false);


--
-- Name: r_trans_partition_schema_id_trans_partition_schema_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_trans_partition_schema_id_trans_partition_schema_seq', 1, false);


--
-- Name: r_trans_slave_id_trans_slave_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_trans_slave_id_trans_slave_seq', 1, false);


--
-- Name: r_transformation_id_transformation_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_transformation_id_transformation_seq', 1, false);


--
-- Name: r_user_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_user_id_user_seq', 1, false);


--
-- Name: r_value_id_value_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_value_id_value_seq', 1, false);


--
-- Name: r_version_id_version_seq; Type: SEQUENCE SET; Schema: public; Owner: rossonet
--

SELECT pg_catalog.setval('public.r_version_id_version_seq', 1, false);


--
-- Name: idx_jatt; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE UNIQUE INDEX idx_jatt ON public.r_job_attribute USING btree (id_job, code, nr);


--
-- Name: idx_rdat; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE UNIQUE INDEX idx_rdat ON public.r_database_attribute USING btree (id_database, code);


--
-- Name: idx_rdir; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE UNIQUE INDEX idx_rdir ON public.r_directory USING btree (id_directory_parent, directory_name);


--
-- Name: idx_rjd1; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE INDEX idx_rjd1 ON public.r_jobentry_database USING btree (id_job);


--
-- Name: idx_rjd2; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE INDEX idx_rjd2 ON public.r_jobentry_database USING btree (id_database);


--
-- Name: idx_rjea; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE UNIQUE INDEX idx_rjea ON public.r_jobentry_attribute USING btree (id_jobentry_attribute, code, nr);


--
-- Name: idx_rsat; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE UNIQUE INDEX idx_rsat ON public.r_step_attribute USING btree (id_step, code, nr);


--
-- Name: idx_rsd1; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE INDEX idx_rsd1 ON public.r_step_database USING btree (id_transformation);


--
-- Name: idx_rsd2; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE INDEX idx_rsd2 ON public.r_step_database USING btree (id_database);


--
-- Name: idx_tatt; Type: INDEX; Schema: public; Owner: rossonet
--

CREATE UNIQUE INDEX idx_tatt ON public.r_trans_attribute USING btree (id_transformation, code, nr);


--
-- PostgreSQL database dump complete
--

